﻿using HealthcareAppointment.Models;
using System.Collections.Generic;

namespace HealthcareAppointment.Data
{
    public class AppDbContext
    {
    }
}
